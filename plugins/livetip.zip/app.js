(function () {
  'use strict';

  var toggle = document.getElementById('toggle');
  var lock = document.getElementById('lock');
  var promptList = document.getElementById('prompt-list');
  var addPrompt = document.getElementById('add-prompt');
  var hostReady = !!(window.ipc && typeof window.ipc.postMessage === 'function');
  var enabled = false;
  var busy = false;
  var draggableState = true;
  var fontList = [];
  var rows = new Map();
  var emptyRow = null;
  var SIZE_PRESETS = [12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 160];
  var OPACITY_PRESETS = [0, 25, 50, 55, 75, 100];
  var FORMATS = [
    ['bold', 'B', '加粗'],
    ['italic', 'I', '倾斜'],
    ['underline', 'U', '下划线'],
    ['strike', 'S', '删除线']
  ];

  function send(message) {
    if (!hostReady) return;
    try {
      window.ipc.postMessage(message);
    } catch (error) {
      toggle.title = '客户端调用失败';
    }
  }

  function updateButton() {
    toggle.textContent = enabled ? '关闭提示层' : '开启提示层';
    toggle.disabled = busy || !hostReady;
  }

  function updateLock() {
    lock.classList.toggle('is-locked', !draggableState);
    lock.title = draggableState ? '锁定位置' : '解锁拖动';
    lock.setAttribute('aria-label', lock.title);
    lock.disabled = !hostReady;
  }

  function make(tag, className) {
    var element = document.createElement(tag);
    if (className) element.className = className;
    return element;
  }

  function ensureNumberOption(select, value, suffix) {
    var text = String(value);
    for (var i = 0; i < select.options.length; i += 1) {
      if (Number(select.options[i].value) === Number(value)) {
        if (select.value !== select.options[i].value) select.value = select.options[i].value;
        return;
      }
    }
    var option = document.createElement('option');
    option.value = text;
    option.textContent = text + (suffix || '');
    select.appendChild(option);
    select.value = text;
  }

  function fillFontOptions(select, value) {
    select.innerHTML = '';
    var names = fontList.slice();
    if (value && names.indexOf(value) < 0) names.push(value);
    names.forEach(function (name) {
      var option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      select.appendChild(option);
    });
    if (value) select.value = value;
  }

  function ensureFontOption(select, value) {
    if (!value) return;
    for (var i = 0; i < select.options.length; i += 1) {
      if (select.options[i].value === value) {
        if (select.value !== value) select.value = value;
        return;
      }
    }
    var option = document.createElement('option');
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
    select.value = value;
  }

  function sendPrompt(id, patch) {
    send('fgsteam-livetip:prompt-update:' + id + ':' + JSON.stringify(patch));
  }

  function createRow(id) {
    var rowElement = make('div', 'prompt-row');
    rowElement.setAttribute('data-id', String(id));

    var textZone = make('div', 'zone text-zone');
    var text = make('span', 'prompt-text');
    var remove = make('button', 'prompt-delete');
    remove.type = 'button';
    remove.textContent = '删除';
    remove.title = '删除';
    remove.setAttribute('aria-label', '删除');
    remove.addEventListener('click', function () {
      send('fgsteam-livetip:prompt-delete:' + id);
    });
    textZone.appendChild(text);

    var styleZone = make('div', 'zone style-zone');
    var font = make('select', 'font-select');
    font.title = '字体';
    fillFontOptions(font, '');
    font.addEventListener('change', function () {
      sendPrompt(id, { font: font.value });
    });
    var color = document.createElement('input');
    color.type = 'color';
    color.className = 'color-input';
    color.value = '#ffffff';
    color.title = '文本颜色';
    color.addEventListener('input', function () {
      sendPrompt(id, { color: color.value });
    });
    var align = make('select', 'align-select');
    align.title = '对齐';
    [['left', '左对齐'], ['center', '居中对齐'], ['right', '右对齐']].forEach(function (item) {
      var option = document.createElement('option');
      option.value = item[0];
      option.textContent = item[1];
      align.appendChild(option);
    });
    align.addEventListener('change', function () {
      sendPrompt(id, { align: align.value });
    });
    var size = make('select', 'size-select');
    size.title = '文本大小';
    SIZE_PRESETS.forEach(function (value) {
      var option = document.createElement('option');
      option.value = String(value);
      option.textContent = String(value);
      size.appendChild(option);
    });
    size.addEventListener('change', function () {
      sendPrompt(id, { size: Number(size.value) });
    });
    var opacity = make('select', 'opacity-select');
    opacity.title = '背景透明度';
    OPACITY_PRESETS.forEach(function (value) {
      var option = document.createElement('option');
      option.value = String(value);
      option.textContent = value + '%';
      opacity.appendChild(option);
    });
    opacity.addEventListener('change', function () {
      sendPrompt(id, { opacity: Number(opacity.value) / 100 });
    });
    styleZone.appendChild(font);
    styleZone.appendChild(color);
    styleZone.appendChild(align);
    styleZone.appendChild(size);
    styleZone.appendChild(opacity);

    var formatZone = make('div', 'zone format-zone');
    var formats = {};
    FORMATS.forEach(function (item) {
      var button = make('button', 'format-btn');
      button.type = 'button';
      button.setAttribute('data-format', item[0]);
      button.textContent = item[1];
      button.title = item[2];
      button.setAttribute('aria-label', item[2]);
      button.addEventListener('click', function () {
        var active = button.classList.toggle('is-active');
        var patch = {};
        patch[item[0]] = active;
        sendPrompt(id, patch);
      });
      formats[item[0]] = button;
      formatZone.appendChild(button);
    });

    formatZone.appendChild(remove);

    rowElement.appendChild(textZone);
    rowElement.appendChild(styleZone);
    rowElement.appendChild(formatZone);
    promptList.appendChild(rowElement);

    var row = {
      element: rowElement,
      text: text,
      font: font,
      color: color,
      align: align,
      size: size,
      opacity: opacity,
      formats: formats
    };
    rows.set(String(id), row);
    return row;
  }

  function updateRow(row, prompt) {
    var value = typeof prompt.text === 'string' ? prompt.text : '';
    row.text.textContent = value.trim() ? value : '（空提示）';
    row.text.title = value;

    var font = typeof prompt.font === 'string' && prompt.font ? prompt.font : 'Microsoft YaHei UI';
    if (document.activeElement !== row.font) {
      ensureFontOption(row.font, font);
    }

    var color = /^#[0-9a-f]{6}$/i.test(prompt.color || '') ? prompt.color : '#ffffff';
    if (document.activeElement !== row.color && row.color.value !== color) {
      row.color.value = color;
    }

    var alignValue = ['left', 'center', 'right'].indexOf(prompt.align) >= 0 ? prompt.align : 'left';
    if (document.activeElement !== row.align && row.align.value !== alignValue) {
      row.align.value = alignValue;
    }

    var size = Number(prompt.size);
    if (!isFinite(size) || size <= 0) size = 32;
    if (document.activeElement !== row.size) {
      ensureNumberOption(row.size, Math.round(size), '');
    }

    var opacity = Number(prompt.opacity);
    if (!isFinite(opacity)) opacity = 0.55;
    opacity = Math.max(0, Math.min(1, opacity));
    if (document.activeElement !== row.opacity) {
      ensureNumberOption(row.opacity, Math.round(opacity * 100), '%');
    }

    FORMATS.forEach(function (item) {
      row.formats[item[0]].classList.toggle('is-active', !!prompt[item[0]]);
    });
  }

  function renderPrompts(prompts) {
    if (!Array.isArray(prompts)) prompts = [];
    var seen = Object.create(null);
    prompts.forEach(function (prompt) {
      if (!prompt || typeof prompt !== 'object' || prompt.id === undefined) return;
      var key = String(prompt.id);
      seen[key] = true;
      var row = rows.get(key) || createRow(prompt.id);
      updateRow(row, prompt);
    });
    Array.from(rows.keys()).forEach(function (key) {
      if (!seen[key]) {
        var row = rows.get(key);
        if (row) row.element.remove();
        rows.delete(key);
      }
    });
    if (!prompts.length) {
      if (!emptyRow) {
        emptyRow = make('div', 'empty-list');
        emptyRow.textContent = '暂无提示文本';
        promptList.appendChild(emptyRow);
      }
    } else if (emptyRow) {
      emptyRow.remove();
      emptyRow = null;
    }
  }

  function renderState(state) {
    if (!state || typeof state !== 'object') return;
    enabled = !!state.enabled;
    if (typeof state.draggable === 'boolean') draggableState = state.draggable;
    renderPrompts(state.prompts);
    busy = false;
    updateButton();
    updateLock();
  }

  function setFonts(list) {
    if (!Array.isArray(list) || !list.length) return;
    fontList = list.filter(function (name) {
      return typeof name === 'string' && name;
    });
    rows.forEach(function (row) {
      var current = row.font.value;
      fillFontOptions(row.font, current);
    });
  }

  window.fgsteamLiveTipState = renderState;
  window.fgsteamLiveTipPrompts = renderPrompts;
  window.fgsteamLiveTipFonts = setFonts;

  lock.addEventListener('click', function () {
    draggableState = !draggableState;
    updateLock();
    send('fgsteam-livetip:settings:' + JSON.stringify({ draggable: draggableState }));
  });

  addPrompt.addEventListener('click', function () {
    send('fgsteam-livetip:prompt-add');
  });

  toggle.addEventListener('click', function () {
    if (busy) return;
    busy = true;
    toggle.disabled = true;
    toggle.textContent = enabled ? '正在关闭…' : '正在开启…';
    send('fgsteam-livetip:enabled:' + (enabled ? '0' : '1'));
  });

  if (!hostReady) {
    toggle.textContent = '请在 FGSteam 中打开';
    toggle.disabled = true;
    addPrompt.disabled = true;
    lock.disabled = true;
    toggle.title = '未连接客户端';
    renderPrompts([]);
    return;
  }

  updateButton();
  updateLock();
  send('fgsteam-livetip:status');
  send('fgsteam-livetip:fonts');
  setInterval(function () {
    if (document.visibilityState !== 'hidden') send('fgsteam-livetip:prompts');
  }, 1200);
})();
