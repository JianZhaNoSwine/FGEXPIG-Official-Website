(function () {
  'use strict';

  var STORAGE_KEY = 'fgsteam.gacha.v1';
  var LEVELS = ['N', 'R', 'SR', 'SSR', 'UR'];
  var LEVEL_CLASS = { N: 'lv-n', R: 'lv-r', SR: 'lv-sr', SSR: 'lv-ssr', UR: 'lv-ur' };
  var CARD_COUNT = 12;
  var SLOT_STEP = 190;
  var TILT_STEP = 11;
  var MAX_TILT = 24;
  var DEPTH = 45;
  var SPIN_MS = 3600;

  var reel = document.getElementById('reel');
  var drawBtn = document.getElementById('draw');
  var settingsBtn = document.getElementById('settings');
  var modal = document.getElementById('settings-modal');
  var closeBtn = document.getElementById('settings-close');
  var cancelBtn = document.getElementById('settings-cancel');
  var saveBtn = document.getElementById('settings-save');
  var toggleBtn = document.getElementById('levels-toggle');
  var addBtn = document.getElementById('add-item');
  var rowsEl = document.getElementById('item-rows');
  var totalEl = document.getElementById('chance-total');
  var errorEl = document.getElementById('settings-error');

  var state = loadState();
  var editing = null;
  var dragState = null;
  var cards = [];
  var position = 0;
  var spinning = false;

  function defaultState() {
    return {
      levels: true,
      items: [
        { name: '谢谢参与', level: 'N', chance: 50 },
        { name: '小奖', level: 'R', chance: 30 },
        { name: '中奖', level: 'SR', chance: 15 },
        { name: '大奖', level: 'SSR', chance: 4 },
        { name: '传说', level: 'UR', chance: 1 }
      ]
    };
  }

  function roundChance(value) {
    return Math.round(value * 100) / 100;
  }

  function normalize(raw) {
    var items = [];
    if (raw && Array.isArray(raw.items)) {
      raw.items.forEach(function (item) {
        if (!item || typeof item !== 'object') return;
        var name = String(item.name || '').trim();
        if (!name) return;
        var level = LEVELS.indexOf(item.level) >= 0 ? item.level : 'N';
        var chance = Number(item.chance);
        if (!isFinite(chance) || chance < 0) chance = 0;
        items.push({ name: name, level: level, chance: roundChance(Math.min(100, chance)) });
      });
    }
    if (!items.length) return defaultState();
    return { levels: !raw || raw.levels !== false, items: items };
  }

  function loadState() {
    try {
      return normalize(JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'));
    } catch (error) {
      return defaultState();
    }
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {}
  }

  function formatChance(value) {
    var text = String(roundChance(value));
    return text;
  }

  function randomItem() {
    var items = state.items.length ? state.items : defaultState().items;
    return items[Math.floor(Math.random() * items.length)];
  }

  function pickWeighted() {
    var items = state.items;
    var total = 0;
    items.forEach(function (item) {
      total += item.chance;
    });
    if (!(total > 0)) return randomItem();
    var roll = Math.random() * total;
    for (var i = 0; i < items.length; i += 1) {
      roll -= items[i].chance;
      if (roll < 0) return items[i];
    }
    return items[items.length - 1];
  }

  /* ---------- 卡片 ---------- */
  function paintCard(card, item) {
    card.classList.remove('is-center', 'lv-n', 'lv-r', 'lv-sr', 'lv-ssr', 'lv-ur', 'lv-off');
    card.classList.add(state.levels ? LEVEL_CLASS[item.level] : 'lv-off');
    card.querySelector('.card-level').textContent = item.level;
    card.querySelector('.card-name').textContent = item.name;
  }

  function buildReel() {
    reel.innerHTML = '';
    cards = [];
    for (var i = 0; i < CARD_COUNT; i += 1) {
      var card = document.createElement('div');
      card.className = 'card';
      var inner = document.createElement('div');
      inner.className = 'card-inner';
      var level = document.createElement('span');
      level.className = 'card-level';
      var name = document.createElement('span');
      name.className = 'card-name';
      inner.appendChild(level);
      inner.appendChild(name);
      card.appendChild(inner);
      reel.appendChild(card);
      cards.push(card);
    }
    resetCards();
  }

  function resetCards() {
    cards.forEach(function (card) {
      paintCard(card, randomItem());
    });
  }

  // 只显示正中与左右各两张的浅弧布局：不是真实圆环，边缘卡片倾角很小。
  function layout(value) {
    for (var i = 0; i < cards.length; i += 1) {
      var offset = i - value;
      offset = ((offset % CARD_COUNT) + CARD_COUNT) % CARD_COUNT;
      if (offset > CARD_COUNT / 2) offset -= CARD_COUNT;
      var distance = Math.abs(offset);
      var card = cards[i];
      if (distance > 2.6) {
        card.style.visibility = 'hidden';
        card.style.opacity = '0';
        continue;
      }
      var tilt = Math.max(-MAX_TILT, Math.min(MAX_TILT, offset * TILT_STEP));
      card.style.visibility = 'visible';
      var opacity = 1;
      if (distance > 2) {
        opacity = Math.max(0, 0.86 * (1 - (distance - 2) / 0.6));
      } else if (distance > 1) {
        opacity = 1 - (distance - 1) * 0.14;
      }
      card.style.opacity = String(opacity);
      card.style.zIndex = String(50 - Math.round(distance * 10));
      card.style.transform =
        'translate3d(' + offset * SLOT_STEP + 'px, 0, ' + -distance * DEPTH + 'px) rotateY(' + tilt + 'deg)';
    }
  }

  function draw() {
    if (spinning) return;
    spinning = true;
    drawBtn.disabled = true;
    settingsBtn.disabled = true;

    var result = pickWeighted();
    var target = Math.floor(Math.random() * CARD_COUNT);
    cards.forEach(function (card, index) {
      paintCard(card, index === target ? result : randomItem());
    });

    var start = position;
    var finalPos =
      target + CARD_COUNT * Math.ceil((start + CARD_COUNT * 3 - target) / CARD_COUNT);
    if (Math.random() < 0.5) finalPos += CARD_COUNT;
    var began = performance.now();
    var finished = false;

    function finish() {
      if (finished) return;
      finished = true;
      position = finalPos;
      layout(position);
      cards[target].classList.add('is-center');
      spinning = false;
      drawBtn.disabled = false;
      settingsBtn.disabled = false;
    }

    function frame(now) {
      var t = Math.min(1, (now - began) / SPIN_MS);
      var eased = 1 - Math.pow(1 - t, 4);
      position = start + (finalPos - start) * eased;
      layout(position);
      if (t < 1) {
        requestAnimationFrame(frame);
      } else {
        finish();
      }
    }
    requestAnimationFrame(frame);
  }

  /* ---------- 设置弹窗 ---------- */
  function showError(message) {
    errorEl.textContent = message;
    errorEl.hidden = false;
  }

  function updateTotal() {
    var total = 0;
    editing.items.forEach(function (item) {
      var value = Number(item.chance);
      if (isFinite(value)) total += value;
    });
    total = roundChance(total);
    totalEl.textContent = '合计 ' + formatChance(total) + '%';
    totalEl.classList.toggle('is-bad', Math.abs(total - 100) > 0.01);
    errorEl.hidden = true;
  }

  function syncToggle() {
    toggleBtn.setAttribute('aria-checked', editing.levels ? 'true' : 'false');
    var card = modal.querySelector('.modal-card');
    if (card) card.classList.toggle('levels-off', !editing.levels);
  }

  function nextLevel(level) {
    var index = LEVELS.indexOf(level);
    return LEVELS[(index + 1) % LEVELS.length];
  }

  function renderRows() {
    rowsEl.innerHTML = '';
    editing.items.forEach(function (item, index) {
      var row = document.createElement('div');
      row.className = 'item-row' + (dragState && dragState.index === index ? ' dragging' : '');

      var name = document.createElement('input');
      name.className = 'item-input';
      name.type = 'text';
      name.maxLength = 40;
      name.autocomplete = 'off';
      name.placeholder = '物品名称';
      name.value = item.name;
      name.addEventListener('input', function () {
        item.name = name.value;
        errorEl.hidden = true;
      });

      var level = document.createElement('button');
      level.type = 'button';
      level.className = 'level-btn ' + LEVEL_CLASS[item.level];
      level.textContent = item.level;
      level.title = '点击切换等级';
      level.setAttribute('aria-label', '等级 ' + item.level + '，点击切换');
      level.addEventListener('click', function () {
        item.level = nextLevel(item.level);
        level.textContent = item.level;
        level.className = 'level-btn ' + LEVEL_CLASS[item.level];
        level.setAttribute('aria-label', '等级 ' + item.level + '，点击切换');
      });

      var chanceWrap = document.createElement('label');
      chanceWrap.className = 'chance-wrap';
      var chance = document.createElement('input');
      chance.className = 'chance-input';
      chance.type = 'number';
      chance.min = '0';
      chance.max = '100';
      chance.step = '0.1';
      chance.value = String(item.chance);
      chance.setAttribute('aria-label', '概率');
      chance.addEventListener('input', function () {
        var value = Number(chance.value);
        if (!isFinite(value) || value < 0) value = 0;
        item.chance = roundChance(Math.min(100, value));
        updateTotal();
      });
      var pct = document.createElement('span');
      pct.className = 'pct';
      pct.textContent = '%';
      chanceWrap.appendChild(chance);
      chanceWrap.appendChild(pct);

      var remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'mini';
      remove.textContent = '×';
      remove.title = '删除';
      remove.setAttribute('aria-label', '删除物品');
      remove.addEventListener('click', function () {
        var index = editing.items.indexOf(item);
        if (index >= 0) editing.items.splice(index, 1);
        renderRows();
      });

      var handle = document.createElement('span');
      handle.className = 'drag-handle';
      handle.title = '拖动排序';
      handle.setAttribute('role', 'button');
      handle.setAttribute('aria-label', '拖动排序');
      for (var bar = 0; bar < 3; bar += 1) {
        handle.appendChild(document.createElement('i'));
      }
      handle.addEventListener('pointerdown', function (event) {
        beginDrag(index, event);
      });

      row.appendChild(handle);
      row.appendChild(name);
      row.appendChild(level);
      row.appendChild(chanceWrap);
      row.appendChild(remove);
      rowsEl.appendChild(row);
    });
    updateTotal();
  }

  function openSettings() {
    if (spinning) return;
    editing = {
      levels: state.levels,
      items: state.items.map(function (item) {
        return { name: item.name, level: item.level, chance: item.chance };
      })
    };
    syncToggle();
    renderRows();
    errorEl.hidden = true;
    modal.hidden = false;
    setTimeout(function () {
      var first = rowsEl.querySelector('.item-input');
      if (first) first.focus();
    }, 30);
  }

  function closeSettings() {
    stopDrag();
    modal.hidden = true;
    editing = null;
  }

  function stopDrag() {
    if (dragState) {
      try {
        modal.releasePointerCapture(dragState.pointerId);
      } catch (error) {}
    }
    dragState = null;
    document.removeEventListener('pointermove', onDragMove);
    document.removeEventListener('pointerup', endDrag);
    document.removeEventListener('pointercancel', endDrag);
    document.body.classList.remove('reordering');
  }

  function beginDrag(index, event) {
    if (!editing || event.button !== 0) return;
    event.preventDefault();
    if (dragState) stopDrag();
    dragState = { index: index, pointerId: event.pointerId };
    try {
      modal.setPointerCapture(event.pointerId);
    } catch (error) {}
    document.addEventListener('pointermove', onDragMove);
    document.addEventListener('pointerup', endDrag);
    document.addEventListener('pointercancel', endDrag);
    document.body.classList.add('reordering');
    renderRows();
  }

  function autoScrollRows(pointerY) {
    var body = modal.querySelector('.modal-body');
    if (!body) return;
    var rect = body.getBoundingClientRect();
    if (pointerY < rect.top + 36) {
      body.scrollTop -= 14;
    } else if (pointerY > rect.bottom - 36) {
      body.scrollTop += 14;
    }
  }

  function onDragMove(event) {
    if (!dragState || event.pointerId !== dragState.pointerId) return;
    var rows = rowsEl.querySelectorAll('.item-row');
    if (!rows.length) return;
    var index = dragState.index;
    if (index > 0) {
      var previous = rows[index - 1].getBoundingClientRect();
      if (event.clientY < previous.top + previous.height / 2) {
        var up = editing.items.splice(index, 1)[0];
        editing.items.splice(index - 1, 0, up);
        dragState.index = index - 1;
        renderRows();
        autoScrollRows(event.clientY);
        return;
      }
    }
    if (index < rows.length - 1) {
      var next = rows[index + 1].getBoundingClientRect();
      if (event.clientY > next.top + next.height / 2) {
        var down = editing.items.splice(index, 1)[0];
        editing.items.splice(index + 1, 0, down);
        dragState.index = index + 1;
        renderRows();
        autoScrollRows(event.clientY);
        return;
      }
    }
    autoScrollRows(event.clientY);
  }

  function endDrag(event) {
    if (dragState && event && event.pointerId !== dragState.pointerId) return;
    stopDrag();
    if (editing) renderRows();
  }

  function saveSettings() {
    if (!editing) return;
    if (!editing.items.length) {
      showError('至少需要一个物品');
      return;
    }
    var items = [];
    var total = 0;
    for (var i = 0; i < editing.items.length; i += 1) {
      var item = editing.items[i];
      var name = String(item.name || '').trim();
      if (!name) {
        showError('物品名称不能为空');
        return;
      }
      var chance = Number(item.chance);
      if (!isFinite(chance) || chance < 0 || chance > 100) {
        showError('概率必须在 0% 到 100% 之间');
        return;
      }
      items.push({ name: name, level: item.level, chance: roundChance(chance) });
      total += chance;
    }
    total = roundChance(total);
    if (Math.abs(total - 100) > 0.01) {
      showError('概率合计必须等于 100%（当前 ' + formatChance(total) + '%）');
      return;
    }
    state = { levels: editing.levels, items: items };
    persist();
    closeSettings();
    resetCards();
  }

  /* ---------- 事件 ---------- */
  drawBtn.addEventListener('click', draw);
  settingsBtn.addEventListener('click', openSettings);
  closeBtn.addEventListener('click', closeSettings);
  cancelBtn.addEventListener('click', closeSettings);
  saveBtn.addEventListener('click', saveSettings);

  toggleBtn.addEventListener('click', function () {
    if (!editing) return;
    editing.levels = !editing.levels;
    syncToggle();
  });

  addBtn.addEventListener('click', function () {
    if (!editing) return;
    editing.items.push({ name: '', level: 'N', chance: 0 });
    renderRows();
    var inputs = rowsEl.querySelectorAll('.item-input');
    if (inputs.length) inputs[inputs.length - 1].focus();
  });

  modal.addEventListener('click', function (event) {
    if (event.target === modal) closeSettings();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && !modal.hidden) closeSettings();
  });

  buildReel();
  layout(0);
  watchVersion();

  /* 插件被更新后自动刷新页面（插件页可能长期保持打开）。 */
  function watchVersion() {
    var baseline = '';
    function check() {
      fetch('plugin.json?ts=' + Date.now(), { cache: 'no-store' })
        .then(function (response) {
          return response.ok ? response.json() : null;
        })
        .then(function (info) {
          if (!info || !info.version) return;
          if (!baseline) {
            baseline = info.version;
          } else if (info.version !== baseline) {
            location.reload();
          }
        })
        .catch(function () {});
    }
    check();
    setInterval(check, 5000);
  }
})();
