(function () {
  'use strict';

  var button = document.getElementById('toggle');
  var slider = document.getElementById('cursor-size');
  var sizeValue = document.getElementById('cursor-size-value');
  var bilibili = document.getElementById('bilibili');
  var active = false;
  var busy = false;
  var sizeTimer = 0;
  var hostReady = !!(window.ipc && typeof window.ipc.postMessage === 'function');

  function sizeToLevel(size) {
    var value = Math.max(32, Math.min(256, Number(size) || 32));
    return Math.max(1, Math.min(15, Math.round((value - 32) / 16) + 1));
  }

  function levelToSize(level) {
    var value = Math.max(1, Math.min(15, Number(level) || 1));
    return 32 + (value - 1) * 16;
  }

  function sizeText(level, size) {
    return level + '（' + size + ' px）';
  }

  function showSize(size) {
    var level = sizeToLevel(size);
    slider.value = String(level);
    sizeValue.textContent = sizeText(level, levelToSize(level));
    slider.disabled = false;
  }

  function render(result) {
    busy = false;
    button.disabled = false;
    if (result && typeof result.size === 'number') showSize(result.size);
    if (result && typeof result.active === 'boolean') active = result.active;
    if (result && result.error) {
      button.textContent = '应用失败 · 重试';
      button.title = String(result.error);
      return;
    }
    button.textContent = active ? '恢复系统指针' : '应用猪标';
    button.title = '';
  }

  window.fgsteamCursorResult = render;
  window.fgsteamCursorSize = function (result) {
    if (result && typeof result.size === 'number') showSize(result.size);
    slider.title = result && result.error ? String(result.error) : '';
  };

  function sendSize(size) {
    if (!hostReady) return;
    try {
      window.ipc.postMessage('fgsteam-cursor:size:' + size);
    } catch (error) {
      slider.title = '无法调整鼠标指针大小：' + String(error);
    }
  }

  slider.addEventListener('input', function () {
    var level = Number(slider.value);
    var size = levelToSize(level);
    sizeValue.textContent = sizeText(level, size);
    clearTimeout(sizeTimer);
    sizeTimer = setTimeout(function () {
      sendSize(size);
    }, 140);
  });

  slider.addEventListener('change', function () {
    clearTimeout(sizeTimer);
    sendSize(levelToSize(Number(slider.value)));
  });

  bilibili.addEventListener('click', function () {
    if (!hostReady) return;
    try {
      window.ipc.postMessage('fgsteam-cursor:bilibili');
    } catch (error) {
      bilibili.title = '无法打开浏览器：' + String(error);
    }
  });

  button.addEventListener('click', function () {
    if (busy) return;
    busy = true;
    button.disabled = true;
    button.textContent = active ? '正在恢复…' : '正在应用…';
    try {
      window.ipc.postMessage(active ? 'fgsteam-cursor:restore' : 'fgsteam-cursor:apply');
    } catch (error) {
      busy = false;
      button.disabled = false;
      button.textContent = '应用失败 · 重试';
      button.title = '无法调用客户端：' + String(error);
    }
  });

  if (!hostReady) {
    button.disabled = true;
    button.textContent = '请在 FGSteam 中打开';
    slider.disabled = true;
    bilibili.disabled = true;
    return;
  }

  try {
    window.ipc.postMessage('fgsteam-cursor:status');
  } catch (error) {
    button.textContent = '应用失败 · 重试';
    button.title = '无法读取指针状态：' + String(error);
  }
})();
