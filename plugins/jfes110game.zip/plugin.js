(function () {
  'use strict';

  var actionButton = null;
  var audio = null;

  // 插件页没有独立关闭按钮：Esc 交给客户端标题栏返回，游戏层保持打开。
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);

  function playMusic() {
    if (!audio) {
      audio = new Audio('/music/minigames.mp3');
      audio.loop = true;
      audio.volume = 1;
    }
    var playing = audio.play();
    if (playing && typeof playing.catch === 'function') {
      playing.catch(function () {});
    }
  }

  function startGame() {
    var api = window.FGEXPIG_MINIGAMES;
    if (!api || typeof api.start !== 'function') return;
    playMusic();
    if (actionButton) actionButton.hidden = true;
    var rect = actionButton ? actionButton.getBoundingClientRect() : null;
    var x = rect ? rect.left + rect.width / 2 : window.innerWidth / 2;
    var y = rect ? rect.top + rect.height / 2 : window.innerHeight * 0.68;
    api.start(x, y);
  }

  function boot() {
    var api = window.FGEXPIG_MINIGAMES;
    if (!api || typeof api.open !== 'function') {
      setTimeout(boot, 50);
      return;
    }
    api.open('JFES110');
    var overlay = document.querySelector('.minigame-overlay');
    if (!overlay) {
      setTimeout(boot, 50);
      return;
    }

    actionButton = document.createElement('button');
    actionButton.type = 'button';
    actionButton.className = 'minigame-plugin-start fg-plugin-primary-action';
    actionButton.textContent = '开始游戏';
    actionButton.addEventListener('click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      startGame();
    });
    overlay.appendChild(actionButton);

    document.addEventListener('fgsteam-game-start', function () {
      if (actionButton) actionButton.hidden = true;
    });
    document.addEventListener('fgsteam-game-end', function () {
      if (!actionButton) return;
      actionButton.textContent = '再来一局';
      actionButton.hidden = false;
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
