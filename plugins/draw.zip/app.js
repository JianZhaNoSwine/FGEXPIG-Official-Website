(function () {
  'use strict';

  var STORAGE_KEY = 'fgsteam.draw.v2';
  var LEGACY_ITEMS_KEY = 'fgsteam.draw.items.v1';
  var LEGACY_HISTORY_KEY = 'fgsteam.draw.history.v1';
  var MAX_HISTORY = 200;
  var DRAW_MS = 2000;
  var PAUSE_MS = 1000;
  var MODES = ['repeat-single', 'unique-single', 'unique-all'];

  function $(id) {
    return document.getElementById(id);
  }

  var listToggle = $('list-toggle');
  var listLabel = $('list-label');
  var listMenu = $('list-menu');
  var itemsEl = $('items');
  var newListBtn = $('new-list');
  var editListBtn = $('edit-list');
  var drawPane = document.querySelector('.pane-draw');
  var resultSingle = $('result-single');
  var resultCaption = $('result-caption');
  var drawBtn = $('draw');
  var modeButtons = Array.prototype.slice.call(document.querySelectorAll('.mode-btn'));
  var historyEl = $('history');
  var historyEmpty = $('history-empty');
  var clearBtn = $('clear');
  var editorModal = $('editor');
  var editorTitle = $('editor-title');
  var editorName = $('editor-name');
  var editorItems = $('editor-items');
  var editorAppend = $('editor-append');
  var editorSave = $('editor-save');
  var editorCancel = $('editor-cancel');
  var editorClose = $('editor-close');
  var editorDelete = $('editor-delete');

  var state = null;
  var animating = false;
  var editor = null;
  var dragState = null;
  var listDragState = null;
  var suppressListClick = false;

  function uid() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function normalizeMode(value) {
    if (MODES.indexOf(value) !== -1) return value;
    if (value && typeof value === 'object') {
      var count = value.count === 'all' ? 'all' : 'single';
      var repeat = value.repeat === 'unique' ? 'unique' : 'repeat';
      if (count === 'all') return 'unique-all';
      return repeat === 'unique' ? 'unique-single' : 'repeat-single';
    }
    return 'repeat-single';
  }

  function normalizeState(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var lists = [];
    var listIds = new Set();
    var sourceLists = Array.isArray(raw.lists) ? raw.lists : [];
    for (var listIndex = 0; listIndex < sourceLists.length; listIndex++) {
      var source = sourceLists[listIndex];
      if (!source || typeof source !== 'object') continue;
      var listId = String(source.id || '');
      if (!listId || listIds.has(listId)) listId = uid();
      listIds.add(listId);
      var name = String(source.name || '').trim() || '未命名列表';
      var items = [];
      var itemIds = new Set();
      var sourceItems = Array.isArray(source.items) ? source.items : [];
      for (var itemIndex = 0; itemIndex < sourceItems.length; itemIndex++) {
        var sourceItem = sourceItems[itemIndex];
        if (!sourceItem || typeof sourceItem !== 'object') continue;
        var text = String(sourceItem.text || '').trim();
        if (!text) continue;
        var itemId = String(sourceItem.id || '');
        if (!itemId || itemIds.has(itemId)) itemId = uid();
        itemIds.add(itemId);
        items.push({ id: itemId, text: text });
      }
      lists.push({ id: listId, name: name, items: items });
    }
    if (!lists.length) {
      return {
        version: 2,
        lists: [],
        selectedId: null,
        mode: 'repeat-single',
        drawn: [],
        history: []
      };
    }
    var selectedId = String(raw.selectedId || '');
    var selectedValid = lists.some(function (list) { return list.id === selectedId; });
    if (!selectedValid) selectedId = lists[0].id;
    var mode = normalizeMode(raw.mode);
    var selectedList = lists.filter(function (list) { return list.id === selectedId; })[0];
    var validIds = new Set(selectedList.items.map(function (item) { return item.id; }));
    var drawn = [];
    if (Array.isArray(raw.drawn)) {
      drawn = raw.drawn.filter(function (id) {
        return typeof id === 'string' && validIds.has(id);
      });
      drawn = Array.from(new Set(drawn));
    }
    var history = [];
    if (Array.isArray(raw.history)) {
      history = raw.history.filter(function (entry) {
        return entry && typeof entry === 'object' && Array.isArray(entry.texts);
      }).map(function (entry) {
        var texts = entry.texts.filter(function (text) {
          return typeof text === 'string' && text.length > 0;
        });
        var entryMode = normalizeMode(
          entry.mode !== undefined
            ? entry.mode
            : (entry.count === 'all' ? 'unique-all' : 'repeat-single')
        );
        return {
          texts: texts,
          time: typeof entry.time === 'number' && isFinite(entry.time) ? entry.time : Date.now(),
          mode: entryMode
        };
      }).filter(function (entry) {
        return entry.texts.length > 0;
      }).slice(0, MAX_HISTORY);
    }
    if (!selectedValid) {
      drawn = [];
      history = [];
    }
    return {
      version: 2,
      lists: lists,
      selectedId: selectedId,
      mode: mode,
      drawn: drawn,
      history: history
    };
  }

  function migrateLegacy() {
    var texts = [];
    try {
      texts = (localStorage.getItem(LEGACY_ITEMS_KEY) || '')
        .split(/\r?\n/)
        .map(function (line) { return line.trim(); })
        .filter(function (line) { return line.length > 0; });
    } catch (e) {}
    var lists = [];
    var selectedId = null;
    if (texts.length) {
      var list = {
        id: uid(),
        name: '默认列表',
        items: texts.map(function (text) { return { id: uid(), text: text }; })
      };
      lists.push(list);
      selectedId = list.id;
    }
    var history = [];
    if (lists.length) {
      try {
        var old = JSON.parse(localStorage.getItem(LEGACY_HISTORY_KEY) || '[]');
        if (Array.isArray(old)) {
          history = old.filter(function (entry) {
            return entry && typeof entry.text === 'string' && entry.text.trim();
          }).map(function (entry) {
            return {
              texts: [entry.text],
              time: Number(entry.time) || Date.now(),
              mode: 'repeat-single'
            };
          }).slice(0, MAX_HISTORY);
        }
      } catch (e) {}
    }
    return {
      version: 2,
      lists: lists,
      selectedId: selectedId,
      mode: 'repeat-single',
      drawn: [],
      history: history
    };
  }

  function loadState() {
    var raw = null;
    try {
      raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    } catch (e) {}
    return normalizeState(raw) || migrateLegacy();
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {}
  }

  function listById(id) {
    for (var index = 0; index < state.lists.length; index++) {
      if (state.lists[index].id === id) return state.lists[index];
    }
    return null;
  }

  function currentList() {
    return listById(state.selectedId);
  }

  function randomIndex(length) {
    if (length <= 1) return 0;
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      var pool = new Uint32Array(1);
      var limit = Math.floor(0x100000000 / length) * length;
      do {
        window.crypto.getRandomValues(pool);
      } while (pool[0] >= limit);
      return pool[0] % length;
    }
    return Math.floor(Math.random() * length);
  }

  function shuffle(items) {
    var result = items.slice();
    for (var index = result.length - 1; index > 0; index--) {
      var pick = randomIndex(index + 1);
      var temp = result[index];
      result[index] = result[pick];
      result[pick] = temp;
    }
    return result;
  }

  function formatTime(timestamp) {
    try {
      return new Date(timestamp).toLocaleTimeString([], {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch (e) {
      return '';
    }
  }

  function closeListMenu() {
    if (listDragState) stopListDrag();
    suppressListClick = false;
    listMenu.hidden = true;
    listToggle.setAttribute('aria-expanded', 'false');
  }

  function openListMenu() {
    if (animating || !state.lists.length) return;
    renderLists();
    var rect = listToggle.getBoundingClientRect();
    var width = Math.max(rect.width, 180);
    var left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8));
    var gap = 6;
    var spaceBelow = window.innerHeight - rect.bottom - gap - 8;
    var spaceAbove = rect.top - gap - 8;
    listMenu.style.width = width + 'px';
    listMenu.style.left = left + 'px';
    if (spaceBelow >= 120 || spaceBelow >= spaceAbove) {
      listMenu.style.top = (rect.bottom + gap) + 'px';
      listMenu.style.bottom = 'auto';
      listMenu.style.maxHeight = Math.min(280, Math.max(96, spaceBelow)) + 'px';
    } else {
      listMenu.style.top = 'auto';
      listMenu.style.bottom = (window.innerHeight - rect.top + gap) + 'px';
      listMenu.style.maxHeight = Math.min(280, Math.max(96, spaceAbove)) + 'px';
    }
    listMenu.hidden = false;
    listToggle.setAttribute('aria-expanded', 'true');
  }

  function stopListDrag() {
    if (listDragState) {
      try {
        listMenu.releasePointerCapture(listDragState.pointerId);
      } catch (e) {}
    }
    listDragState = null;
    document.removeEventListener('pointermove', onListDragMove);
    document.removeEventListener('pointerup', endListDrag);
    document.removeEventListener('pointercancel', endListDrag);
    document.body.classList.remove('reordering');
  }

  function beginListDrag(event, index) {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    if (listDragState) stopListDrag();
    suppressListClick = true;
    listDragState = { index: index, pointerId: event.pointerId, moved: false };
    try {
      listMenu.setPointerCapture(event.pointerId);
    } catch (e) {}
    document.addEventListener('pointermove', onListDragMove);
    document.addEventListener('pointerup', endListDrag);
    document.addEventListener('pointercancel', endListDrag);
    document.body.classList.add('reordering');
    renderLists();
  }

  function autoScrollListMenu(pointerY) {
    var rect = listMenu.getBoundingClientRect();
    if (pointerY < rect.top + 26) {
      listMenu.scrollTop -= 12;
    } else if (pointerY > rect.bottom - 26) {
      listMenu.scrollTop += 12;
    }
  }

  function onListDragMove(event) {
    if (!listDragState || event.pointerId !== listDragState.pointerId) return;
    var options = listMenu.querySelectorAll('.list-option');
    if (!options.length) return;
    var index = listDragState.index;
    if (index > 0) {
      var previous = options[index - 1].getBoundingClientRect();
      if (event.clientY < previous.top + previous.height / 2) {
        var up = state.lists.splice(index, 1)[0];
        state.lists.splice(index - 1, 0, up);
        listDragState.index = index - 1;
        listDragState.moved = true;
        renderLists();
        autoScrollListMenu(event.clientY);
        return;
      }
    }
    if (index < options.length - 1) {
      var next = options[index + 1].getBoundingClientRect();
      if (event.clientY > next.top + next.height / 2) {
        var down = state.lists.splice(index, 1)[0];
        state.lists.splice(index + 1, 0, down);
        listDragState.index = index + 1;
        listDragState.moved = true;
        renderLists();
        autoScrollListMenu(event.clientY);
        return;
      }
    }
    autoScrollListMenu(event.clientY);
  }

  function endListDrag(event) {
    if (listDragState && event && event.pointerId !== listDragState.pointerId) return;
    var moved = listDragState ? listDragState.moved : false;
    stopListDrag();
    if (moved) {
      saveState();
      clearSession();
    }
    renderLists();
    setTimeout(function () {
      suppressListClick = false;
    }, 0);
  }

  function selectList(id) {
    closeListMenu();
    if (animating || !id || id === state.selectedId) return;
    state.selectedId = id;
    saveState();
    clearSession();
    renderAll();
  }

  function renderLists() {
    var selected = currentList();
    listLabel.textContent = selected ? selected.name : '暂无列表';
    listMenu.innerHTML = '';
    if (!state.lists.length) {
      closeListMenu();
      return;
    }
    state.lists.forEach(function (list, index) {
      var option = document.createElement('button');
      option.type = 'button';
      option.className = 'list-option' + (list.id === state.selectedId ? ' selected' : '');
      if (listDragState && listDragState.index === index) option.classList.add('dragging');
      option.setAttribute('role', 'option');
      option.setAttribute('aria-selected', list.id === state.selectedId ? 'true' : 'false');

      var name = document.createElement('span');
      name.className = 'name';
      name.textContent = list.name;

      var handle = document.createElement('span');
      handle.className = 'drag-handle';
      handle.title = '拖动排序列表';
      handle.setAttribute('role', 'button');
      handle.setAttribute('aria-label', '拖动排序列表');
      for (var bar = 0; bar < 3; bar++) {
        handle.appendChild(document.createElement('i'));
      }
      handle.addEventListener('pointerdown', function (event) {
        beginListDrag(event, index);
      });
      handle.addEventListener('click', function (event) {
        event.stopPropagation();
      });

      option.append(name, handle);
      option.addEventListener('click', function () {
        if (suppressListClick) return;
        selectList(list.id);
      });
      listMenu.appendChild(option);
    });
  }

  function renderItems() {
    itemsEl.innerHTML = '';
    var list = currentList();
    editListBtn.disabled = animating || !list;
    if (!list) {
      var row = document.createElement('li');
      row.className = 'item-empty';
      row.textContent = '还没有列表，点击右侧“＋”新建。';
      itemsEl.appendChild(row);
      return;
    }
    if (!list.items.length) {
      var empty = document.createElement('li');
      empty.className = 'item-empty';
      empty.textContent = '列表为空，点击右上角“编辑”添加项。';
      itemsEl.appendChild(empty);
      return;
    }
    list.items.forEach(function (item, index) {
      var row = document.createElement('li');
      var number = document.createElement('span');
      number.className = 'idx';
      number.textContent = String(index + 1);
      var text = document.createElement('span');
      text.className = 'text';
      text.textContent = item.text;
      text.title = item.text;
      row.append(number, text);
      itemsEl.appendChild(row);
    });
  }

  function renderModes() {
    for (var index = 0; index < modeButtons.length; index++) {
      var button = modeButtons[index];
      var selected = button.dataset.mode === state.mode;
      button.classList.toggle('selected', selected);
      button.setAttribute('aria-pressed', selected ? 'true' : 'false');
    }
    updateControls();
  }

  function updateControls() {
    var list = currentList();
    var hasItems = !!list && list.items.length > 0;
    drawBtn.disabled = animating || !hasItems;
    drawBtn.textContent = animating ? '抽取中…' : '抽签';
    listToggle.disabled = animating || !state.lists.length;
    newListBtn.disabled = animating;
    editListBtn.disabled = animating || !list;
    clearBtn.disabled = animating || (!state.history.length && !state.drawn.length);
    for (var index = 0; index < modeButtons.length; index++) {
      modeButtons[index].disabled = animating;
    }
    if (animating || !state.lists.length) closeListMenu();
  }

  function renderHistory() {
    historyEl.innerHTML = '';
    historyEl.hidden = state.history.length === 0;
    historyEmpty.hidden = state.history.length > 0;
    for (var index = 0; index < state.history.length; index++) {
      var entry = state.history[index];
      var card = document.createElement('li');
      card.className = 'history-entry';

      var meta = document.createElement('div');
      meta.className = 'history-meta';
      var time = document.createElement('span');
      time.textContent = formatTime(entry.time);
      var badge = document.createElement('span');
      badge.className = 'history-badge';
      badge.textContent = entry.mode === 'unique-all' ? '连抽' : '单抽';
      meta.append(time, badge);

      var body = document.createElement('div');
      for (var textIndex = 0; textIndex < entry.texts.length; textIndex++) {
        var row = document.createElement('div');
        row.className = 'history-text';
        if (entry.texts.length > 1) {
          var number = document.createElement('span');
          number.className = 'no';
          number.textContent = String(textIndex + 1);
          row.appendChild(number);
        }
        var text = document.createElement('span');
        text.className = 'txt';
        text.textContent = entry.texts[textIndex];
        text.title = entry.texts[textIndex];
        row.appendChild(text);
        body.appendChild(row);
      }

      card.append(meta, body);
      historyEl.appendChild(card);
    }
  }

  function isExhausted() {
    var list = currentList();
    if (!list || !list.items.length || state.mode === 'repeat-single') return false;
    var valid = new Set(list.items.map(function (item) { return item.id; }));
    var drawn = new Set(state.drawn.filter(function (id) { return valid.has(id); }));
    return drawn.size >= valid.size;
  }

  function drawPool(list) {
    if (state.mode === 'repeat-single') return list.items.slice();
    var drawn = new Set(state.drawn);
    return list.items.filter(function (item) { return !drawn.has(item.id); });
  }

  function restartProgress() {
    drawPane.classList.remove('drawing');
    void drawPane.offsetWidth;
    drawPane.classList.add('drawing');
  }

  function resetResult() {
    resultSingle.hidden = false;
    resultSingle.className = 'result-single';
    resultSingle.textContent = '—';
    resultCaption.hidden = true;
    resultCaption.textContent = '';
    drawPane.classList.remove('drawing');
  }

  function clearSession() {
    state.history = [];
    state.drawn = [];
    saveState();
    resetResult();
    renderHistory();
    updateControls();
  }

  function wait(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  function rollTo(targetText, names, duration) {
    return new Promise(function (resolve) {
      var start = performance.now();
      var nextAt = start;
      var last = -1;
      function frame(now) {
        var progress = Math.min(1, (now - start) / duration);
        if (now >= nextAt) {
          var index = randomIndex(names.length);
          if (names.length > 1 && index === last) {
            index = (index + 1 + randomIndex(names.length - 1)) % names.length;
          }
          last = index;
          resultSingle.textContent = names[index];
          nextAt = now + 45 + 245 * progress * progress;
        }
        if (progress < 1) {
          requestAnimationFrame(frame);
        } else {
          resultSingle.textContent = targetText;
          resultSingle.className = 'result-single has-value pop';
          resolve();
        }
      }
      requestAnimationFrame(frame);
    });
  }

  function commitDraw(items, mode) {
    if (mode !== 'repeat-single') {
      var drawn = new Set(state.drawn);
      items.forEach(function (item) { drawn.add(item.id); });
      state.drawn = Array.from(drawn);
    }
    state.history.unshift({
      texts: items.map(function (item) { return item.text; }),
      time: Date.now(),
      mode: mode
    });
    state.history = state.history.slice(0, MAX_HISTORY);
    saveState();
    renderHistory();
    historyEl.scrollTop = 0;
    updateControls();
  }

  function drawSingle(pool) {
    var target = pool[randomIndex(pool.length)];
    animating = true;
    resultSingle.hidden = false;
    resultSingle.className = 'result-single rolling';
    resultSingle.textContent = '抽签中…';
    resultCaption.hidden = true;
    resultCaption.textContent = '';
    updateControls();
    restartProgress();
    var names = pool.map(function (item) { return item.text; });
    rollTo(target.text, names, DRAW_MS).then(function () {
      commitDraw([target], state.mode);
      drawPane.classList.remove('drawing');
      animating = false;
      updateControls();
    });
  }

  async function drawAllSequential(pool) {
    var sequence = shuffle(pool);
    if (!sequence.length) return;
    animating = true;
    resultSingle.hidden = false;
    resultSingle.className = 'result-single rolling';
    resultSingle.textContent = '抽签中…';
    resultCaption.hidden = false;
    resultCaption.textContent = '连抽 · 共 ' + sequence.length + ' 项';
    updateControls();
    var names = sequence.map(function (item) { return item.text; });
    for (var index = 0; index < sequence.length; index++) {
      var item = sequence[index];
      resultCaption.textContent = '连抽 · 第 ' + (index + 1) + ' / ' + sequence.length + ' 个';
      resultSingle.className = 'result-single rolling';
      resultSingle.textContent = '抽签中…';
      restartProgress();
      await rollTo(item.text, names, DRAW_MS);
      commitDraw([item], 'unique-all');
      if (index < sequence.length - 1) {
        drawPane.classList.remove('drawing');
        await wait(PAUSE_MS);
      }
    }
    drawPane.classList.remove('drawing');
    resultCaption.textContent = '连抽 · 共 ' + sequence.length + ' 项';
    animating = false;
    updateControls();
  }

  function draw() {
    if (animating) return;
    var list = currentList();
    if (!list || !list.items.length) return;
    if (state.mode !== 'repeat-single' && isExhausted()) {
      state.history = [];
      state.drawn = [];
      saveState();
      resetResult();
      renderHistory();
    }
    var pool = drawPool(list);
    if (!pool.length) return;
    closeListMenu();
    if (state.mode === 'unique-all') {
      drawAllSequential(pool);
    } else {
      drawSingle(pool);
    }
  }

  function clearHistory() {
    if (animating) return;
    if (!state.history.length && !state.drawn.length) return;
    if (!window.confirm('清空历史记录？')) return;
    state.history = [];
    state.drawn = [];
    saveState();
    resetResult();
    renderHistory();
    updateControls();
  }

  function nextListName() {
    var index = 1;
    var name = '新列表';
    while (state.lists.some(function (list) { return list.name === name; })) {
      index += 1;
      name = '新列表 ' + index;
    }
    return name;
  }

  function openNewList() {
    if (animating) return;
    closeListMenu();
    editor = {
      mode: 'new',
      listId: null,
      name: nextListName(),
      items: [{ id: uid(), text: '' }]
    };
    openEditor();
  }

  function openEditList() {
    if (animating) return;
    closeListMenu();
    var list = currentList();
    if (!list) return;
    editor = {
      mode: 'edit',
      listId: list.id,
      name: list.name,
      items: list.items.map(function (item) {
        return { id: item.id, text: item.text };
      })
    };
    openEditor();
  }

  function openEditor() {
    editorTitle.textContent = editor.mode === 'new' ? '新建列表' : '编辑列表';
    editorName.value = editor.name;
    editorDelete.hidden = editor.mode !== 'edit';
    editorSave.disabled = !editor.name.trim();
    editorModal.hidden = false;
    renderEditorItems();
    requestAnimationFrame(function () {
      editorName.focus();
      editorName.select();
    });
  }

  function stopEditorDrag() {
    if (dragState) {
      try {
        editorModal.releasePointerCapture(dragState.pointerId);
      } catch (e) {}
    }
    dragState = null;
    document.removeEventListener('pointermove', onEditorDragMove);
    document.removeEventListener('pointerup', endEditorDrag);
    document.removeEventListener('pointercancel', endEditorDrag);
    document.body.classList.remove('reordering');
  }

  function closeEditor() {
    stopEditorDrag();
    editor = null;
    editorModal.hidden = true;
    editorItems.innerHTML = '';
  }

  function updateEditorSave() {
    editorSave.disabled = !editor || !editorName.value.trim();
  }

  function miniButton(label, title, handler) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'mini';
    button.textContent = label;
    button.title = title;
    button.setAttribute('aria-label', title);
    button.addEventListener('click', handler);
    return button;
  }

  function renderEditorItems() {
    editorItems.innerHTML = '';
    if (!editor.items.length) {
      var empty = document.createElement('div');
      empty.className = 'editor-empty';
      empty.textContent = '还没有列表项，点击“添加项”开始。';
      editorItems.appendChild(empty);
      return;
    }
    editor.items.forEach(function (item, index) {
      var row = document.createElement('div');
      row.className = 'editor-row';
      if (dragState && dragState.index === index) row.classList.add('dragging');

      var handle = document.createElement('span');
      handle.className = 'drag-handle';
      handle.title = '拖动排序';
      handle.setAttribute('role', 'button');
      handle.setAttribute('aria-label', '拖动排序');
      for (var bar = 0; bar < 3; bar++) {
        handle.appendChild(document.createElement('i'));
      }
      handle.addEventListener('pointerdown', function (event) {
        beginEditorDrag(event, index);
      });

      var number = document.createElement('span');
      number.className = 'idx';
      number.textContent = String(index + 1);

      var input = document.createElement('input');
      input.type = 'text';
      input.className = 'item-input';
      input.value = item.text;
      input.maxLength = 200;
      input.placeholder = '输入列表项';
      input.autocomplete = 'off';
      input.addEventListener('input', function () {
        item.text = input.value;
      });

      var insert = miniButton('＋', '在上方插入', function () {
        insertEditorItem(index);
      });

      var remove = miniButton('×', '删除', function () {
        removeEditorItem(index);
      });
      remove.classList.add('danger');

      row.append(handle, number, input, insert, remove);
      editorItems.appendChild(row);
    });
  }

  function focusEditorInput(index) {
    var inputs = editorItems.querySelectorAll('.item-input');
    var input = inputs[index];
    if (input) {
      input.focus();
      input.scrollIntoView({ block: 'nearest' });
    }
  }

  function beginEditorDrag(event, index) {
    if (!editor || event.button !== 0) return;
    event.preventDefault();
    if (dragState) stopEditorDrag();
    dragState = { index: index, pointerId: event.pointerId };
    try {
      editorModal.setPointerCapture(event.pointerId);
    } catch (e) {}
    document.addEventListener('pointermove', onEditorDragMove);
    document.addEventListener('pointerup', endEditorDrag);
    document.addEventListener('pointercancel', endEditorDrag);
    document.body.classList.add('reordering');
    renderEditorItems();
  }

  function autoScrollEditor(pointerY) {
    var body = editorModal.querySelector('.modal-body');
    if (!body) return;
    var rect = body.getBoundingClientRect();
    if (pointerY < rect.top + 36) {
      body.scrollTop -= 14;
    } else if (pointerY > rect.bottom - 36) {
      body.scrollTop += 14;
    }
  }

  function onEditorDragMove(event) {
    if (!dragState || event.pointerId !== dragState.pointerId) return;
    var rows = editorItems.querySelectorAll('.editor-row');
    if (!rows.length) return;
    var index = dragState.index;
    if (index > 0) {
      var previous = rows[index - 1].getBoundingClientRect();
      if (event.clientY < previous.top + previous.height / 2) {
        var up = editor.items.splice(index, 1)[0];
        editor.items.splice(index - 1, 0, up);
        dragState.index = index - 1;
        renderEditorItems();
        autoScrollEditor(event.clientY);
        return;
      }
    }
    if (index < rows.length - 1) {
      var next = rows[index + 1].getBoundingClientRect();
      if (event.clientY > next.top + next.height / 2) {
        var down = editor.items.splice(index, 1)[0];
        editor.items.splice(index + 1, 0, down);
        dragState.index = index + 1;
        renderEditorItems();
        autoScrollEditor(event.clientY);
        return;
      }
    }
    autoScrollEditor(event.clientY);
  }

  function endEditorDrag(event) {
    if (dragState && event && event.pointerId !== dragState.pointerId) return;
    stopEditorDrag();
    if (editor) renderEditorItems();
  }

  function insertEditorItem(index) {
    if (!editor) return;
    editor.items.splice(index, 0, { id: uid(), text: '' });
    renderEditorItems();
    focusEditorInput(index);
  }

  function appendEditorItem() {
    if (!editor) return;
    var index = editor.items.length;
    editor.items.push({ id: uid(), text: '' });
    renderEditorItems();
    focusEditorInput(index);
  }

  function removeEditorItem(index) {
    if (!editor) return;
    editor.items.splice(index, 1);
    renderEditorItems();
    if (editor.items.length) {
      focusEditorInput(Math.min(index, editor.items.length - 1));
    }
  }

  function saveEditor() {
    if (!editor) return;
    var name = editorName.value.trim();
    if (!name) {
      editorName.focus();
      return;
    }
    var items = [];
    var seen = new Set();
    editor.items.forEach(function (item) {
      var text = item.text.trim();
      if (!text) return;
      var id = item.id;
      if (!id || seen.has(id)) id = uid();
      seen.add(id);
      items.push({ id: id, text: text });
    });
    var changed = false;
    if (editor.mode === 'new') {
      var list = { id: uid(), name: name, items: items };
      state.lists.push(list);
      state.selectedId = list.id;
      changed = true;
    } else {
      var existing = listById(editor.listId);
      if (!existing) {
        closeEditor();
        return;
      }
      var same = existing.name === name &&
        existing.items.length === items.length &&
        existing.items.every(function (item, index) {
          return item.text === items[index].text;
        });
      if (!same) {
        existing.name = name;
        existing.items = items;
        changed = true;
      }
    }
    closeEditor();
    if (changed) {
      saveState();
      clearSession();
    }
    renderLists();
    renderItems();
    renderModes();
    renderHistory();
    updateControls();
  }

  function deleteEditorList() {
    if (!editor || editor.mode !== 'edit') return;
    var list = listById(editor.listId);
    if (!list) return;
    if (!window.confirm('删除列表“' + list.name + '”？列表中的项也会一起删除。')) return;
    state.lists = state.lists.filter(function (item) { return item.id !== list.id; });
    if (state.selectedId === list.id) {
      state.selectedId = state.lists.length ? state.lists[0].id : null;
    }
    closeEditor();
    saveState();
    clearSession();
    renderLists();
    renderItems();
    renderModes();
    renderHistory();
    updateControls();
  }

  function bindEvents() {
    listToggle.addEventListener('click', function (event) {
      event.stopPropagation();
      if (animating || !state.lists.length) return;
      if (listMenu.hidden) {
        openListMenu();
      } else {
        closeListMenu();
      }
    });
    document.addEventListener('click', function (event) {
      if (listMenu.hidden) return;
      var target = event.target;
      if (target instanceof Element && (target.closest('.list-picker') || target.closest('#list-menu'))) {
        return;
      }
      closeListMenu();
    });

    newListBtn.addEventListener('click', openNewList);
    editListBtn.addEventListener('click', openEditList);
    drawBtn.addEventListener('click', draw);
    clearBtn.addEventListener('click', clearHistory);

    modeButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        if (animating) return;
        var mode = button.dataset.mode;
        if (!mode || state.mode === mode) return;
        state.mode = mode;
        saveState();
        clearSession();
        renderModes();
        renderHistory();
        updateControls();
      });
    });

    editorName.addEventListener('input', function () {
      if (!editor) return;
      editor.name = editorName.value;
      updateEditorSave();
    });
    editorAppend.addEventListener('click', appendEditorItem);
    editorSave.addEventListener('click', saveEditor);
    editorCancel.addEventListener('click', closeEditor);
    editorClose.addEventListener('click', closeEditor);
    editorDelete.addEventListener('click', deleteEditorList);
    editorModal.addEventListener('mousedown', function (event) {
      if (event.target === editorModal) closeEditor();
    });
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      if (!listMenu.hidden) {
        event.preventDefault();
        closeListMenu();
      } else if (!editorModal.hidden) {
        event.preventDefault();
        closeEditor();
      }
    });
    window.addEventListener('blur', function () {
      if (listDragState) {
        endListDrag();
      }
      if (dragState) {
        stopEditorDrag();
        if (editor) renderEditorItems();
      }
    });
    window.addEventListener('resize', function () {
      closeListMenu();
    });
  }

  state = loadState();
  saveState();
  bindEvents();
  renderAll();
  resetResult();
  updateControls();

  function renderAll() {
    renderLists();
    renderItems();
    renderModes();
    renderHistory();
    updateControls();
  }
})();
